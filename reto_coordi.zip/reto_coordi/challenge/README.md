### Reto coordinadora

### Conocimiento teórico

1)- Con sus propias palabras explique que es una inyección de dependencias y para qué sirve

Entiendo por inyección de dependencia, un patrón de diseño orientado a objeto de una aplicación y que tiene como finalidad solucionar un problema 
que los desarrolladores encuentran en la construcción de aplicaciones y que permite mantener los componentes o capas de una aplicación lo más desacoplada posible.

2)- Explique con sus propias palabras las diferencias entre asíncrono y sincrono

### Asincrono
Entiendo por asíncrono la capacidad de ejecutar nuestros procesos en varios hilos de ejecución que también se conoce como multihilos.

### Sincrono
Este no permite ejecutar un segundo proceso hasta que el primero haya finalizado lo que genera una cola o tráfico dentro de la aplicación

3)- Cuál es la importancia del uso de promesas en un proyecto

La importancia de usar promesas en una aplicación es porque es un objeto que representa la terminación o el fracaso de una operación asincrónica

4)- Cual es la importancia de usar ORM dentro de un proyecto, ventaja y desventaja

La importancia de usuar ORM es que permite a la hora de trasladar el modelo conceptual al esquema relacional nativo de las base de datos SQL lo que a su vez 
permite la migración hacia otro sistema de gestor de base de datos lo que incorpora una capa de abstracción entre el modelo relacional fisico y la capa
de negocios de la aplicación. 

### Ventajas al usar ORM
Una de las ventajas de usar ORM es la rápidez que permite en el desarrollo, Abtracción de la base de datos, Reutilización, Seguridad, Mantenimiento del código,
Lenguaje propio para realizar las consultas.

### Desventajas al usar ORM
Las desventajas que tiene al usuario ORM es que se requiere de un buen tiempo para su aprendizaje debido a que suelen ser herramienta un poco complejas otra
desventajas es que las aplicaciones tienden aser un poco mas lentas debido a que las consultas que se hagan sobre la base de datos, el sistema primero deberá
transformarla al lenguaje propio de la herramienta.

5)- Que diferencia hay entre una base de datos SQL, NOSQL

La diferencia que hay entre SQL y NOSQL es que SQL permite combinar de forma efieciente diferentes tablas para extraer información relacionada, tambien permite 
gestionar los datos junto con las los datos junto con las relaciones existente entre ellos; en cambio NOSQL permite distribuir grandes cantidades de información
y también permite un escalado orizontal sin problemas por su capacidad de distribución miestras que escalar SQL resulta mas cplicado.

6)- Si hablo de colección y documentos me refiero a?

### Colección
Se refiere a un conjunto de documentos de base de datos NoSQL.

### Documentos
Se refiere al cojunto de pares clave-valor que puede ser designado como documento y es una representación binaria de documentos JSON

7)- Si una aplicación está sacando error de CORS a que se está refiriendo?

Esto se refiere que cuando se pretende tener acceso desde un dominio A a un dominio B y este no está configurado para su acceso el CORS muestras un error 
denegado por consola, este tipo de error se ve mucho para el consumo de API.






